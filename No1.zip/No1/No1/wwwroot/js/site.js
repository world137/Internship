﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.
$(document).ready(function () {
    $("#add_button").on("click", function () {
        

        var table = document.getElementById("main_table");
        var index_row = table.rows.length;
        console.log(index_row); // ตำแหน่งสำหรับเพิ่มแถวในตาราง


        var row = table.insertRow(index_row-1);
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        var cell4 = row.insertCell(3);
        var cell5 = row.insertCell(4);
        cell1.innerHTML = "";
        cell2.innerHTML = '<input class="form-control A_input" type="number" name="a" id="A_input"></input>';
        cell3.innerHTML = '<input class="form-control B_input" type="number" name="b" id="B_input"></input>';
        cell4.innerHTML = "";
        cell5.innerHTML = "<button class='btn btn-danger rounded-pill del' id='del'>delete</button>";
        
        
        $(".A_input").off("change")
        $(".A_input").on("change", function () {
            let value_A = $(this).val()
            $(this).val(check_value($(this).val()))
            console.log("helloworld")
            console.log($(this).val())
            change_val()
        })
        $('.B_input').off("change")
        $(".B_input").on("change", function () {
            let value_B = Number($(this).val())
            $(this).val(check_value(value_B))
            change_val()

        })
        $(".del").off("click")
        $(".del").on("click", function () {
            var index_row = $(this).parent().parent().index()
            console.log(index_row)
            table.deleteRow(index_row)
            change_val()
        })
    });

});

function change_val() {
    
    var table = document.getElementById("main_table");
    var all_a = 0
    var all_b = 0
    for (var i = 2; i < table.rows.length - 1; i++) {
        var a = table.rows[i].cells[1].children[0].value;
        var b = table.rows[i].cells[2].children[0].value;
        all_a += Number(a);
        all_b += Number(b);
        console.log("all a" + a)
        console.log("all b" + b)
        table.rows[i].cells[3].innerHTML = Number(a) + Number(b);
    }
    table.rows[table.rows.length - 1].cells[1].innerHTML = all_a;
    table.rows[table.rows.length - 1].cells[2].innerHTML = all_b;
    table.rows[table.rows.length - 1].cells[3].innerHTML = all_a + all_b;

} function check_value(number) {
    let max = Number.MAX_SAFE_INTEGER;
    let min = Number.MIN_SAFE_INTEGER
    console.log("number" + number)

    console.log(max)
    console.log("min" + min)
    if (number > max) {
        alert("input > max")
        return max;
    }
    if (number < min) {
        alert("input < min")
        return min;
    }
        return number
    
}

