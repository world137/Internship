using No2_cs.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;


namespace Name.Controllers
{
    [ApiController]
    [Route("api/")]
    
    public class OutPutController : ControllerBase
    {
        
        private static List<DataModel> data = new List<DataModel>();
            
        
        [HttpGet("data")]
        public APIModel Get()
        {
            APIModel output = new APIModel();
            output.Data = data;
            output.Status = new StatusModel{Code="200",Message="OK"};
            return output;
        }

        [HttpPost("add")]
        public APIModel Post([FromBody] DataModel input)
        {
            APIModel output = new APIModel();
            data.Add(new DataModel{Code = input.Code, Name = input.Name});
            output.Data = data;
            output.Status = new StatusModel{Code="200",Message="OK"};
            return output;
        }


        [HttpPost("edit")]
            
        public APIModel Edit([FromBody] DataModel input)
        {
            APIModel output = new APIModel();
            DataModel new_value = data.Where(x => x.Code == input.Code).FirstOrDefault();
            new_value.Name = input.Name;
            output.Data = data;
            output.Status = new StatusModel{Code="200",Message="OK"};
            return output;
        }

        [HttpPost("delete")]
        public APIModel Delete([FromBody] DataModel input)
        {
            APIModel output = new APIModel();
            data.Remove(data.Where(x => x.Code == input.Code).FirstOrDefault());
            output.Data = data;
            output.Status = new StatusModel{Code="200",Message="OK"};
            return output;
        }

    }
}