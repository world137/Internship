using System.Collections.Generic;
namespace No2_cs.Models
{
    public class APIModel
    {
        public StatusModel Status { get; set; }

        public List<DataModel> Data { get; set; }
    }
}