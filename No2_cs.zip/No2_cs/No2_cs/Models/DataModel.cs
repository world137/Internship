namespace No2_cs.Models
{
    public class DataModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
        
    }
}