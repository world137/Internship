
namespace WebAppAndApi.Models
{
    public class ApplicationConfiguration
    {
        public string SiteRootUrl { get; set; }
    }
}
