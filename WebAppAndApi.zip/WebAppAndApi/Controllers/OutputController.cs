using No3.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;


namespace Name.Controllers
{
    // [ApiController]
    // [Route("api/")]
    
    // public class OutPutController : ControllerBase
    // {
        
    //     private static List<DataModel> data = new List<DataModel>();
            
        
    //     [HttpGet("data")]
    //     public APIModel Get()
    //     {
    //         APIModel output = new APIModel();
    //         output.Data = data;
    //         output.Status = new StatusModel{Code="200",Message="OK"};
    //         return output;
    //     }

    //     [HttpPost("add")]
    //     public APIModel Post([FromBody] DataModel input)
    //     {
    //         APIModel output = new APIModel();
    //         var input_code = input.Code;
    //         DataModel chack_code = data.Find(x => x.Code == input_code);
    //         if(chack_code != null)
    //         {
    //             output.Data = data;
    //             output.Status = new StatusModel{Code="400",Message="Bad Request"};
    //             return output;
    //         }
           

    //         data.Add(new DataModel{Code = input.Code, Name = input.Name});
    //         output.Data = data;
    //         output.Status = new StatusModel{Code="200",Message="OK"};
    //         return output;
    //     }


    //     [HttpPost("edit")]
            
    //     public APIModel Edit([FromBody] DataModel input)
    //     {
    //         APIModel output = new APIModel();
    //         DataModel new_value = data.Where(x => x.Code == input.Code).FirstOrDefault();
    //         new_value.Name = input.Name;
    //         output.Data = data;
    //         output.Status = new StatusModel{Code="200",Message="OK"};
    //         return output;
    //     }

    //     [HttpPost("delete")]
    //     public APIModel Delete([FromBody] DataModel input)
    //     {
    //         APIModel output = new APIModel();
    //         data.Remove(data.Where(x => x.Code == input.Code).FirstOrDefault());
    //         output.Data = data;
    //         output.Status = new StatusModel{Code="200",Message="OK"};
    //         return output;
    //     }

    // }
}