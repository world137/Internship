using WebAppAndApi.Entities;
using System.Collections.Generic;
using WebAppAndApi.Repositories.EfCore;
using WebAppAndApi.Repositories.Interfaces;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace WebAppAndApi.Features.No3.Repositories
{
    public class No3Repository : INo3Repository
    {
        // เชื่อม database
        private readonly ApplicationContext database;

        public No3Repository(ApplicationContext database)
        {
            this.database = database;
        }
        public List<Code_name> GetAll(){
            return database.Code_name.ToList();
        }
        public Code_name Find(string code){
            return database.Code_name.Find(code);
        }
        public void Add(Code_name Code_name){
            database.Code_name.Add(Code_name);
            database.SaveChanges();
        }
        public void Update(Code_name Code_name){
            database.Entry(Code_name).State = EntityState.Modified;
            database.SaveChanges();
        }
        public void Delete(Code_name Code_name){
            database.Code_name.Remove(Code_name);
            database.SaveChanges();
        }

        
    }

}