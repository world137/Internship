using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using WebAppAndApi.Repositories.Interfaces;
using WebAppAndApi.Entities;
using No3.Models;
using System.Linq;
using WebAppAndApi.Features.No3.Repositories;

namespace WebAppAndApi.Features.No3.Views
{

    [ApiController]
    [Route("api3/")]
    public class No3ApiController : ControllerBase
    {
        private readonly INo3Repository data;

        public No3ApiController(INo3Repository data)
        {
            this.data = data;
        }
            
        
        [HttpGet("data")]
        public APIModel Get()
        {
            APIModel output = new APIModel();
            output.Data = data.GetAll();
            output.Status = new StatusModel{Code="200",Message="OK"};
            return output;
        }

        [HttpPost("add")]
        public APIModel Post([FromBody] Code_name input)
        {
            APIModel output = new APIModel();
            
            Code_name chack_code = data.Find(input.Code);
            if(chack_code != null)
            {
                output.Data = data.GetAll();
                output.Status = new StatusModel{Code="400",Message="Bad Request"};
                return output;
            }
            
            Code_name new_data = new Code_name(){Code = input.Code, Codename = input.Codename};
            

            data.Add(new_data);
            output.Data = data.GetAll();
            output.Status = new StatusModel{Code="200",Message="OK"};
            return output;
        }

        [HttpPost("edit")]

        public APIModel Put([FromBody] Code_name input)
        {
            APIModel output = new APIModel();
            
            Code_name check_code = data.Find(input.Code);
            check_code.Codename = input.Codename;

            output.Data = data.GetAll();
            output.Status = new StatusModel{Code="200",Message="OK"};
            return output;
        }


        [HttpPost("delete")]

        public APIModel Delete([FromBody] Code_name input)
        {
            APIModel output = new APIModel();
            
            Code_name check_code = data.Find(input.Code);
            data.Delete(check_code);
            output.Data = data.GetAll();
            output.Status = new StatusModel{Code="200",Message="OK"};
            return output;
        }
        


        

        
    }
}
