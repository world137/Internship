namespace No3.Models
{
    public class DataModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
        
    }
}