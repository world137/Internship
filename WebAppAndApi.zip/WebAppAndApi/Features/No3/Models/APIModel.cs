using System.Collections.Generic;

using WebAppAndApi.Entities;

namespace No3.Models
{
    public class APIModel
    {
        public StatusModel Status { get; set; }

        public List<Code_name> Data { get; set; }
    }
}