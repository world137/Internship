namespace No3.Models
{
    public class StatusModel
    {
        public string Code { get; set; }
        public string Message { get; set; }
    }
}