using Microsoft.AspNetCore.Mvc;

namespace WebAppAndApi.Features.No3.Views
{
    public class No3Controller : Controller
    {
        public IActionResult No3()
        {
            return View();
        }
    }
    
}