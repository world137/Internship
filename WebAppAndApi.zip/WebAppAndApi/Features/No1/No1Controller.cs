using Microsoft.AspNetCore.Mvc;
namespace WebAppAndApi.Features.No1.Views
{
    public class No1Controller : Controller
    {
        public IActionResult No1()
        {
            return View();
        }
    }
}