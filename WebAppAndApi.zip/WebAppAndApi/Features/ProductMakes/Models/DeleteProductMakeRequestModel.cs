using System.ComponentModel.DataAnnotations;


namespace WebAppAndApi.Features.ProductMakes.Models
{
    public class DeleteProductMakeRequestModel
    {
        public int ProductMakeCode { get; set;}
        public string ProductMakeDesc {get; set;}
        public string ProductMakeCodeName { get; set;}
        public int Active { get; set;}
    }
}