using System.ComponentModel.DataAnnotations;


namespace WebAppAndApi.Features.ProductMakes.Models
{
    public class CreateProductMakeRequestModel
    {
        [Required]
        public int ProductMakeCode { get; set;}
        [Required]
        [StringLength(100)]
        public string ProductMakeDesc {get; set;}
        [Required]
        [StringLength(100)]
        public string ProductMakeCodeName { get; set;}
        public int Active { get; set;}
    }
}