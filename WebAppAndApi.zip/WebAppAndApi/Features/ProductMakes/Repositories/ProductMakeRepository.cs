using System.Collections.Generic;
using System.Linq;
using WebAppAndApi.Entities;
using WebAppAndApi.Repositories.EfCore; 
using WebAppAndApi.Repositories.Interfaces;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace WebAppAndApi.Features.ProductMakes.Repositories
{
    public class ProductMakesRepository : IProductMakesRepository
    {
        private readonly ApplicationContext db;

        public ProductMakesRepository(ApplicationContext db)
        {
            this.db = db;
        }
        public List<ProductMake> FindAll()
        {
            return db.ProductMake.ToList();
        }
        public void Add(ProductMake productmake)
        {
            db.ProductMake.Add(productmake);
        }
        public int Update(ProductMake productmake)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("@ProductMakeCode", SqlDbType.Int) { Value = productmake.ProductMakeCode },
                new SqlParameter("@ProductMakeDesc", SqlDbType.VarChar) { Value = productmake.ProductMakeDesc },
                new SqlParameter("@ProductMakeCodeName", SqlDbType.VarChar) { Value = productmake.ProductMakeCodeName },
            };

            string sqlString = @"UPDATE ProductMake
                SET ProductMakeDesc = @ProductMakeDesc, 
                ProductMakeCodeName = @ProductMakeCodeName
                WHERE ProductMakeCode = @ProductMakeCode;";
            return db.Database.ExecuteSqlRaw(sqlString, parameters);
        }

        public int Delete(ProductMake productmake)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("@ProductMakeCode", SqlDbType.Int) { Value = productmake.ProductMakeCode },
            };
            string sqlString = @"DELETE FROM ProductMake
                WHERE ProductMakeCode = @ProductMakeCode;"; 
            return db.Database.ExecuteSqlRaw(sqlString, parameters);
        }
    }
}