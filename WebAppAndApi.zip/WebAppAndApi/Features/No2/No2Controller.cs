using Microsoft.AspNetCore.Mvc;
namespace WebAppAndApi.Features.No2.Views
{
    public class No2Controller : Controller
    {
        public IActionResult No2()
        {
            return View();
        }
    }
}