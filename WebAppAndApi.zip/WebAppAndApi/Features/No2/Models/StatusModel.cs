namespace No2_cs.Models
{
    public class StatusModel
    {
        public string Code { get; set; }
        public string Message { get; set; }
    }
}