using WebAppAndApi.Features.ProductMakes.Models;
using Newtonsoft.Json;

namespace WebAppAndApi.Entities
{
    public class ProductMake
    {
        public int ProductMakeCode { get; set;}
        public string ProductMakeDesc {get; set;}
        public string ProductMakeCodeName { get; set;}
        public int Active { get; set;}
        public static ProductMake Create(CreateProductMakeRequestModel model)
        {
            return JsonConvert.DeserializeObject<ProductMake>(JsonConvert.SerializeObject(model));
        }
    }
}