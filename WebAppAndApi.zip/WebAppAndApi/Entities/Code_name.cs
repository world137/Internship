namespace WebAppAndApi.Entities
{
    public class Code_name
    {
        public string Code { get; set; }
        public string Codename { get; set; }
    }
}