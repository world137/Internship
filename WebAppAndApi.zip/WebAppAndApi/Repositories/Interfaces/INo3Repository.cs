using System.Collections.Generic;
using WebAppAndApi.Entities;
namespace WebAppAndApi.Repositories.Interfaces
{
    public interface INo3Repository
    {
        List<Code_name> GetAll();
        Code_name Find(string code);
        void Add(Code_name Code_name);
        void Update(Code_name Code_name);
        void Delete(Code_name Code_name);
    }
}