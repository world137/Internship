let arr = [];
$(document).ready(function() {

    $("#add_button").click(function() {
        var modal_edit = $("#modal_edit");
        modal_edit.css("display", "none");
        var modal_del = $("#modal_del");
        modal_del.css("display", "none");
        var modal_add = $("#modal_add");
        modal_add.css("display", "block");
        var span_add = $(".close_add");

        span_add.click(function() {
            modal_add.css("display", "none");
        });
        $(window).click(function(event) {
            if (event.target == modal_add) {
                modal_add.css("display", "none");
            }
        });
    });



    $("#submit").click(function() {
        var modal_edit = $("#modal_edit");
        modal_edit.css("display", "none");
        var table = $("#main_table");
        var code = $("#code_input").val();
        var name = $("#name_input").val();

        if (code == "" || name == "") {
            alert("code or name is null");
        } else if (arr.indexOf(code) != -1) {
            alert("code is exist");

        } else {
            $.ajax({
                type: "POST",
                url: "https://localhost:5001/api3/add",
                datatype: "json",
                data: JSON.stringify({
                    Code: $("#code_input").val(),
                    Codename: $("#name_input").val()
                }),
                contentType: "application/json ; charset=utf-8",
                error() {
                    $("#error_arlert").html("<p>Ajax input Error</p>");
                },
                success: function(output) {
                    console.log(output.status.code);
                    if (output.status.code == "400") {
                        alert("code is exist");
                        return false;
                    }
                    arr.push(code);
                    console.log(arr);
                    var row_html = "<tr><td>" + code + "</td><td>" + name + "</td><td><button class='btn btn-warning mr-1 edit_button'>edit</button><button class='btn btn-danger delete_button'>delete</button></td></tr>";
                    table.append(row_html);
                    var modal_add = $("#modal_add");
                    modal_add.css("display", "none");

                    $("#code_input").val("");
                    $("#name_input").val("");
                }
            });
        }
    });

    let table = $("#main_table");
    table.on("click", ".edit_button", function() {
        var row = $(this).parent().parent().index();
        edit(row)

        let table = $("#main_table");
        let index = table.find("tr").eq(row).find("td").eq(0).html();
        console.log(row)
        console.log(index)
        $("#code_in_edit").val(index);

        var modal_del = $("#modal_del");
        modal_del.css("display", "none");
        var modal_add = $("#modal_add");
        modal_add.css("display", "none");
        var modal_edit = $("#modal_edit");
        modal_edit.css("display", "block");
        var span_edit = $(".close_edit");
        span_edit.click(function() {
            modal_edit.css("display", "none");
        });
        $(window).click(function(event) {
            if (event.target == modal_edit) {
                modal_edit.css("display", "none");
            }
        });

    });
    table.on("click", ".delete_button", function() {

        var row = $(this).parent().parent();
        del(row);

        var modal_add = $("#modal_add");
        modal_add.css("display", "none");
        var modal_edit = $("#modal_edit");
        modal_edit.css("display", "none");
        var modal_del = $("#modal_del");
        modal_del.css("display", "block");
        var span_del = $(".close_del");
        span_del.click(function() {
            modal_del.css("display", "none");
        });
        $(window).click(function(event) {
            if (event.target == modal_del) {
                modal_del.css("display", "none");
            }
        });


    });

    $("#cancle_del").click(function() {
        var modal_del = $("#modal_del");
        modal_del.css("display", "none");
    });
});


function del(button) {
    var modal_del = $("#modal_del");
    modal_del.css("display", "none");
    var modal_add = $("#modal_add");
    modal_add.css("display", "none");
    var modal_edit = $("#modal_edit");
    modal_edit.css("display", "none");


    $("#confirm_del").off("click");
    $("#confirm_del").click(function() {
        let table = $("#main_table");

        let code_del = table.find("tr").eq(button.index()).find("td").eq(0).html()
        console.log(code_del);

        $.ajax({
            type: "POST",
            url: "https://localhost:5001/api3/delete",
            datatype: "json",
            data: JSON.stringify({
                Code: code_del

            }),
            contentType: "application/json ; charset=utf-8",
            error() {
                $("#error_arlert").html("<p>Ajax Delete Error</p>");
            },
            success: function() {

                var value = arr.indexOf(code_del)

                arr.splice(value, 1);
                button.remove();

                console.log(arr);
                var modal_del = $("#modal_del");
                modal_del.css("display", "none");
            }
        });
    });
}

function edit(button) {

    console.log(button);
    var modal_add = $("#modal_add");
    modal_add.css("display", "none");
    $("#confirm_edit").off("click");
    $("#confirm_edit").click(function() {

        $.ajax({
            type: "POST",
            url: "https://localhost:5001/api3/edit",
            datatype: "json",
            data: JSON.stringify({
                Code: $("#code_in_edit").val(),
                Codename: $("#input_edit").val()
            }),
            contentType: "application/json ; charset=utf-8",
            error() {
                $("#error_arlert").html("<p>Ajax Edit Error</p>");
            },
            success: function() {

                var table = $("#main_table");
                var input_edit = $("#input_edit").val();

                console.log(input_edit);
                if (input_edit == "") {
                    alert("name is null");
                } else {
                    var cell = table.find("tr").eq(button).find("td").eq(1);
                    cell.text(input_edit)
                    var modal_edit = $("#modal_edit");
                    modal_edit.css("display", "none");
                    $("#input_edit").val("");
                }
            }
        });
    });
}

// ดึงค่ามาแสดงผล

$.ajax({
    type: "GET",
    url: "https://localhost:5001/api3/data",
    data: {
        format: "json"
    },
    error() {
        $("#error_arlert").html("<p>Ajax output Error</p>");
    },
    success: function(input) {
        console.log("input" + input)
        for (i = 0; i < input.data.length; i++) {
            let code = input.data[i].code
            let name = input.data[i].codename
            let table = $("#main_table");
            let row_html = "<tr><td>" + code + "</td><td>" + name + "</td><td><button class='btn btn-warning mr-1 edit_button'>edit</button><button class='btn btn-danger delete_button'>delete</button></td></tr>";
            table.append(row_html);
        }
    },
});