let ProductmakeList;
let modal = document.getElementById('id01');
let CreateRes = ["บันทึกสำเร็จ","บันทึกไม่สำเร็จ","ไม่สามารถสร้างสินค้าได้"];
let UpdateRes = ["แก้ไขสำเร็จ","แก้ไขไม่สำเร็จ","ไม่สามารถแก้ไขสินค้าได้"];
let Identity = "null";
let SelectMode = "Create";
let dynamicAction;

var tbody = $('tbody');
$(document).ready(function () {
    var counter = 1;
    $.ajax({
        url: `${siteRootUrl}api/ProductMakes/list`,
        type: "GET",
        async: false,
        success: function (res) {
            ProductmakeList = res.data;
        },
        error: function (res) {
            alert('ไม่สามารถดึงข้อมูลสินค้าได้');
        }
    });
    let i = 0;
    let len = ProductmakeList.length;
    let listpProductmakes = "";
    for (; i < len; ) {
        listpProductmakes = ProductmakeList[i];
        //console.log(listpProductmakes['productMakeDesc']); 
        counter++;
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td><input type="number" id="varA' + counter + '" value="'+ listpProductmakes['productMakeCode'] +'"/></td>';
        cols += '<td><input type="text" id="varB' + counter + '" value="'+ listpProductmakes['productMakeDesc'] +'"/></td>';
        cols += '<td><input type="text" id="varC' + counter + '" value="'+ listpProductmakes['productMakeCodeName'] +'"/></td>';
        cols += '<td><input type="number" id="varD' + counter + '" value="'+ listpProductmakes['active'] +'"/></td>';
        cols += '<td><button class="deleteRow btn-dark" id="varE'+counter+'"> DELETE </button></td>';
        cols += '<td><button class="editRow btn-dark" id="varF'+counter+'"> EDIT </button></td>';
        newRow.append(cols);
        $("table.order-list").append(newRow);
        i++;
      }
    $("#addrow").on("click", function () {
        dynamicAction = ApiSelector(SelectMode,Identity);
        if (dynamicAction['request']['ProductMakeCodeName'] == '') {
            alert("You didn't fill Product Name!");
            $("#id01").find('input[name^="input-ProductMakeName"]').val('');
        }
        if (dynamicAction['request']['ProductMakeDesc'] == '') {
            alert("You didn't fill Product Description!");
            $("#id01").find('input[name^="input-ProductMakeDesc"]').val('');
        }
        if (dynamicAction['request']['ProductMakeCodeName'] != '' && dynamicAction['request']['ProductMakeDesc'] != '') {
            $.ajax({
                url: dynamicAction['action'],
                method: 'POST',
                data: JSON.stringify(dynamicAction['request']),
                dataType: 'json',
                contentType: "application/json; charset=utf-8",
                success: function (res) {
                    if (res.status.code == 200) {
                        alert(dynamicAction['Status'][0]);
                        reloadPage();
                    } else {
                        alert(dynamicAction['Status'][1]);
                    }
                },
                error: function (res) {
                    alert(dynamicAction['Status'][2]);
                }
            });
        }
    });
    $("table.order-list").on("click", "button.editRow", function (event) {
        var rowlocation = this.id;
        var thisloc = '#'+'varA'+parseInt(rowlocation.replace(/[^0-9.]/g, ""));
        Identity = $(thisloc).val();
        SelectMode = "Upate";
        modal.style.display = "block";
    });
    $("table.order-list").on("click", "button.deleteRow", function (event) {
        //alert('แน่ใจนะครับว่าจะลบ!');
        var rowlocation = this.id;
        var thisloc = '#'+'varA'+parseInt(rowlocation.replace(/[^0-9.]/g, ""));
        //alert($(thisloc).val());
        var ProductMakeCode = parseInt($(thisloc).val());
        alert(ProductMakeCode);
        $.ajax({
            url: `${siteRootUrl}api/ProductMakes/Delete`,
            method: 'POST',
            data: JSON.stringify({ProductMakeCode:ProductMakeCode}),
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (res) {
                if (res.status.code == 200) {
                    alert('ลบข้อมูลสำเร็จ');
                    reloadPage();
                } else {
                    alert('ลบไม่สำเร็จ');
                }
            },
            error: function (res) {
                alert('ไม่สามารถลบสินค้าได้');
            }
        });
    });
});
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
        $("#id01").find('input[name^="input-ProductMakeDesc"]').val('');
        $("#id01").find('input[name^="input-ProductMakeName"]').val('');
    }
}
function reloadPage(){
    location.reload(true);
}

function ApiSelector(sel,iden){
    var ProductMakeDesc = $("#id01").find('input[name^="input-ProductMakeDesc"]').val();
    var ProductMakeCodeName = $("#id01").find('input[name^="input-ProductMakeName"]').val();
    if (sel == "Create"){
        var action = `${siteRootUrl}api/ProductMakes/Create`;
        var Req = {
            ProductMakeDesc: ProductMakeDesc,
            ProductMakeCodeName: ProductMakeCodeName
        }
        var Status = CreateRes;
    } else if (sel == "Upate") {
        var ProductMakeCode = parseInt(iden);
        var action = `${siteRootUrl}api/ProductMakes/Update`;
        var Req = {
            ProductMakeCode: ProductMakeCode,
            ProductMakeDesc: ProductMakeDesc,
            ProductMakeCodeName: ProductMakeCodeName
        }
        var Status = UpdateRes;
    }
    return {action: action, request: Req,Status:Status}
}




